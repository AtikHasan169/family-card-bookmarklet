/* Family Card Pro — bookmarklet edition
 * Host this folder on HTTPS (GitHub Pages, Cloudflare Pages, Netlify, etc.).
 */
(function () {
  'use strict';

  if (!/(^|\.)bhata\.gov\.bd$/i.test(location.hostname)) {
    alert('Family Card Pro works on bhata.gov.bd pages.');
    return;
  }

  const fallbackUrl = 'https://atikhasan169.github.io/family-card-bookmarklet/bookmarklet.js';
  const currentScript = document.currentScript;
  const scriptSrc = (currentScript && currentScript.src) ? currentScript.src : fallbackUrl;
  
  const cleanScriptSrc = scriptSrc.split('?')[0];
  const baseUrl = new URL('.', cleanScriptSrc).href;
  
  const panelUrl = new URL('sidepanel.html?t=' + Date.now(), baseUrl).href;
  const panelOrigin = new URL(panelUrl).origin;

  const existingRoot = document.getElementById('fc-floating-root');
  if (existingRoot) existingRoot.remove();
  document.querySelectorAll('script[src*="sidepanel"], style[data-fc]').forEach(el => el.remove());

  /* Bundled Vue form injector */
  (function () {
    const RELATION_ID_MAP = {
      'Father': 157, 'Mother': 158, 'Husband': 159, 'Son': 160, 'Daughter': 161,
      'Brother': 162, 'Sister': 163, 'Father-in-law': 164, 'Mother-in-law': 165,
      'Son-in-law': 181, 'Daughter-in-law': 182, 'Grandson': 183, 'Granddaughter': 184,
      'Head/Self': 185, 'Wife': 186, 'Other Relative': 263
    };

    const ID_TO_RELATION_MAP = {
      157: 'Father', 158: 'Mother', 159: 'Husband', 160: 'Son', 161: 'Daughter',
      162: 'Brother', 163: 'Sister', 164: 'Father-in-law', 165: 'Mother-in-law',
      181: 'Son-in-law', 182: 'Daughter-in-law', 183: 'Grandson', 184: 'Granddaughter',
      185: 'Head/Self', 186: 'Wife', 263: 'Other Relative'
    };

    const RELATION_GENDER_MAP = {
      'Father': 1, 'Mother': 2, 'Husband': 1, 'Son': 1, 'Daughter': 2,
      'Brother': 1, 'Sister': 2, 'Father-in-law': 1, 'Mother-in-law': 2,
      'Son-in-law': 1, 'Daughter-in-law': 2, 'Grandson': 1, 'Granddaughter': 2,
      'Head/Self': 2, 'Wife': 2
    };

    function resolveGenderId(memberObj) {
      if (memberObj.gender_id) return Number(memberObj.gender_id);
      const g = String(memberObj.gender || '').toLowerCase();
      if (g === 'female' || g === '2') return 2;
      if (g === 'male' || g === '1') return 1;
      if (g === 'other' || g === '3') return 3;
      if (memberObj.relation && RELATION_GENDER_MAP[memberObj.relation]) {
        return RELATION_GENDER_MAP[memberObj.relation];
      }
      return 1;
    }

    function getVueNodes() {
      let vmHead = null, vmMembers = null;
      const allVms = [];
      document.querySelectorAll('*').forEach(node => {
        const v = node.__vue__;
        if (v) {
          allVms.push(v);
          if (v.data && typeof v.data === 'object' && (
            'name_bn' in v.data || 'name_en' in v.data || 'verification_number' in v.data ||
            'nid' in v.data || 'gender' in v.data || 'gender_id' in v.data || 'date_of_birth' in v.data
          )) {
            vmHead = v;
          }
          if (Array.isArray(v.familyMembers)) vmMembers = v;
        }
      });
      return { vmHead, vmMembers, allVms };
    }

    function determineIsNID(docType, cleanId) {
      const up = String(docType || '').toUpperCase().trim();
      if (up === 'BRN') return false;
      if (up === 'NID') return true;
      if (cleanId.length === 10 || cleanId.length === 13) return true;
      if (cleanId.length === 17) return false;
      return true;
    }

    function parseDobParts(rawDob) {
      if (!rawDob) return null;
      const clean = String(rawDob).replace(/\[.*?\]/g, '').trim();
      let dd, mm, yyyy;
      const dmy = clean.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
      if (dmy) {
        dd = dmy[1].padStart(2, '0');
        mm = dmy[2].padStart(2, '0');
        yyyy = dmy[3];
      } else {
        const ymd = clean.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
        if (ymd) {
          yyyy = ymd[1];
          mm = ymd[2].padStart(2, '0');
          dd = ymd[3].padStart(2, '0');
        } else {
          return null;
        }
      }
      return {
        dd,
        mm,
        yyyy,
        iso: `${yyyy}-${mm}-${dd}`,
        slash: `${dd}/${mm}/${yyyy}`,
        dash: `${dd}-${mm}-${yyyy}`
      };
    }

    function calculateAgeYears(rawDob) {
      const parts = parseDobParts(rawDob);
      if (!parts) return null;
      const yyyy = parseInt(parts.yyyy, 10);
      const mm = parseInt(parts.mm, 10);
      const dd = parseInt(parts.dd, 10);
      const today = new Date();
      let age = today.getFullYear() - yyyy;
      const mDiff = (today.getMonth() + 1) - mm;
      if (mDiff < 0 || (mDiff === 0 && today.getDate() < dd)) {
        age--;
      }
      return age;
    }

    function findAllVueComponents(rootVm, filterFn, visited = new Set()) {
      const results = [];
      if (!rootVm || visited.has(rootVm)) return results;
      visited.add(rootVm);
      if (filterFn(rootVm)) results.push(rootVm);
      if (Array.isArray(rootVm.$children)) {
        rootVm.$children.forEach(child => {
          results.push(...findAllVueComponents(child, filterFn, visited));
        });
      }
      return results;
    }

    function isDatePickerVm(v) {
      if (!v || !v.$options) return false;
      const tag = String(v.$options._componentTag || v.$options.name || '').toLowerCase();
      return tag.includes('date-picker') || tag.includes('datepicker') || ('tableDate' in v && 'activePicker' in v);
    }

    function isMenuOrDialogVm(v) {
      if (!v || !v.$options) return false;
      const tag = String(v.$options._componentTag || v.$options.name || '').toLowerCase();
      return (tag.includes('v-menu') || tag.includes('v-dialog')) && 'isActive' in v;
    }

    async function selectDateViaVuetifyCalendar(rawDob, targetIndex = 0) {
      const parts = parseDobParts(rawDob);
      if (!parts) return;

      const setReactive = (vmTarget, targetObj, key, val) => {
        if (!targetObj || val === undefined || val === null) return;
        if (vmTarget && typeof vmTarget.$set === 'function') vmTarget.$set(targetObj, key, val);
        else targetObj[key] = val;
      };

      const dobContainers = [];
      document.querySelectorAll('.v-input, .form-group').forEach(wrap => {
        if (wrap.closest('#fc-floating-root')) return;
        const txt = (wrap.textContent || '').toLowerCase();
        const inp = wrap.querySelector('input');
        const meta = inp ? `${inp.name || ''} ${inp.id || ''} ${inp.placeholder || ''}`.toLowerCase() : '';
        if (txt.includes('জন্ম তারিখ') || txt.includes('date of birth') || /birth|dob/.test(meta)) {
          if (!dobContainers.some(c => c.contains(wrap) || wrap.contains(c))) {
            dobContainers.push(wrap);
          }
        }
      });

      const targetWrap = dobContainers[targetIndex];
      let menuVm = null;
      let wrapperVm = null;

      if (targetWrap) {
        let curr = targetWrap.__vue__;
        let depth = 0;
        while (curr && depth < 7) {
          if (!menuVm && isMenuOrDialogVm(curr)) menuVm = curr;
          if (!menuVm && Array.isArray(curr.$children)) {
            const childMenu = curr.$children.find(isMenuOrDialogVm);
            if (childMenu) menuVm = childMenu;
          }
          if (curr.$data && ('date' in curr.$data || 'dateFormatted' in curr.$data || 'dob' in curr.$data || 'date_of_birth' in curr.$data)) {
            wrapperVm = curr;
          }
          curr = curr.$parent;
          depth++;
        }
      }

      let openedMenuTemporarily = false;
      if (menuVm && !menuVm.isActive) {
        menuVm.isActive = true;
        openedMenuTemporarily = true;
        await new Promise(r => setTimeout(r, 80));
      }

      // Find all mounted <v-date-picker> instances (including detached Vuetify menu portals)
      const allPickers = [];
      document.querySelectorAll('.v-picker, .v-date-picker-table, *').forEach(n => {
        if (n.__vue__ && isDatePickerVm(n.__vue__) && !allPickers.includes(n.__vue__)) {
          allPickers.push(n.__vue__);
        }
      });

      const targetPicker = (menuVm && findAllVueComponents(menuVm, isDatePickerVm)[0]) || allPickers[targetIndex] || allPickers[allPickers.length - 1];
      if (targetPicker) {
        // Set table month/year and emit official Vuetify date selection events
        if ('tableDate' in targetPicker) targetPicker.tableDate = `${parts.yyyy}-${parts.mm}`;
        if ('internalActivePicker' in targetPicker) targetPicker.internalActivePicker = 'DATE';
        targetPicker.$emit('input', parts.iso);
        targetPicker.$emit('change', parts.iso);
        targetPicker.$emit('click:date', parts.iso);
      }

      if (wrapperVm && wrapperVm.$data) {
        if ('date' in wrapperVm.$data) setReactive(wrapperVm, wrapperVm.$data, 'date', parts.iso);
        if ('dob' in wrapperVm.$data) setReactive(wrapperVm, wrapperVm.$data, 'dob', parts.iso);
        if ('date_of_birth' in wrapperVm.$data) setReactive(wrapperVm, wrapperVm.$data, 'date_of_birth', parts.iso);
        if ('dateFormatted' in wrapperVm.$data) setReactive(wrapperVm, wrapperVm.$data, 'dateFormatted', parts.slash);
        if (typeof wrapperVm.formatDate === 'function') {
          try { wrapperVm.formatDate(parts.iso); } catch (e) {}
        }
      }

      // Only directly set DOM input if it is NOT a readonly Vuetify menu activator
      if (targetWrap) {
        const inp = targetWrap.querySelector('input');
        if (inp && inp._flatpickr) {
          inp._flatpickr.setDate(parts.iso, true);
        } else if (inp && !inp.readOnly && !menuVm) {
          const displayVal = inp.type === 'date' ? parts.iso : parts.slash;
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
          if (nativeSetter) nativeSetter.call(inp, displayVal);
          else inp.value = displayVal;
          inp.dispatchEvent(new Event('input', { bubbles: true }));
          inp.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }

      if (openedMenuTemporarily && menuVm) {
        await new Promise(r => setTimeout(r, 50));
        menuVm.isActive = false;
      }
    }


    function applySmartFormDefaults(vmHead, vmMembers, totalMembers, childrenUnder18, isEthnic = 0, areaTypeId = 1) {
      const setReactive = (vmTarget, targetObj, key, val) => {
        if (!targetObj || val === undefined || val === null) return;
        if (vmTarget && typeof vmTarget.$set === 'function') vmTarget.$set(targetObj, key, val);
        else targetObj[key] = val;
      };

      const d = (vmHead && vmHead.data) ? vmHead.data : null;

      let resolvedAreaId = areaTypeId;
      if (vmHead && vmHead.$data && areaTypeId === 1) {
        Object.entries(vmHead.$data).forEach(([k, list]) => {
          if (Array.isArray(list) && list.length > 0 && list.length <= 20 && typeof list[0] === 'object' && list[0] !== null) {
            const matchItem = list.find(item => {
              const txt = `${item.name_bn || ''} ${item.name_en || ''} ${item.name || ''} ${item.title_bn || ''} ${item.label || ''} ${item.text || ''}`.toLowerCase();
              return /পল্লী|ইউনিয়ন|ইউনিয়ন|rural|union/.test(txt);
            });
            if (matchItem) {
              const idKey = ('id' in matchItem) ? 'id' : (('value' in matchItem) ? 'value' : (('code' in matchItem) ? 'code' : null));
              if (idKey) resolvedAreaId = matchItem[idKey];
            }
          }
        });
      }

      if (d) {
        [
          'house_size', 'total_member', 'total_members', 'family_member_count',
          'total_family_member', 'total_family_members', 'member_count',
          'no_of_family_member', 'number_of_family_members', 'household_size', 'khana_member'
        ].forEach(k => {
          if (k in d || k === 'house_size') setReactive(vmHead, d, k, totalMembers);
        });

        [
          'children_count', 'child_count', 'no_of_children', 'number_of_children',
          'total_children', 'total_child', 'under_18_member', 'children_under_18',
          'sishu_count', 'shishu_count', 'child_member', 'children'
        ].forEach(k => {
          if (k in d && typeof d[k] !== 'object') setReactive(vmHead, d, k, childrenUnder18);
        });

        Object.keys(d).forEach(k => {
          const low = k.toLowerCase();
          if (/child|shishu|sishu|under_18/.test(low) && typeof d[k] !== 'object') {
            setReactive(vmHead, d, k, childrenUnder18);
          }
          if ((/^(total_member|member_count|family_size|house_size|khana_size)$/.test(low)) && typeof d[k] !== 'object') {
            setReactive(vmHead, d, k, totalMembers);
          }
          if (/ethnic|tribal|nrigosthi|nrigosthy|adibashi|indigenous|minority/.test(low)) {
            if (typeof d[k] === 'boolean') setReactive(vmHead, d, k, Boolean(isEthnic));
            else if (!low.endsWith('_name') && !low.endsWith('_type_id')) setReactive(vmHead, d, k, Number(isEthnic));
          }
          if (/^(location_type|location_type_id|area_type|area_type_id|geo_type|present_location_type|permanent_location_type|residence_area_type)$/.test(low)) {
            setReactive(vmHead, d, k, resolvedAreaId);
          }
        });
      }

      if (vmMembers && Array.isArray(vmMembers.familyMembers)) {
        vmMembers.familyMembers.forEach(row => {
          if (!row || typeof row !== 'object') return;
          Object.keys(row).forEach(k => {
            if (/ethnic|tribal|nrigosthi|nrigosthy|adibashi|indigenous|minority/i.test(k)) {
              if (typeof row[k] === 'boolean') setReactive(vmMembers, row, k, Boolean(isEthnic));
              else setReactive(vmMembers, row, k, Number(isEthnic));
            }
          });
        });
      }

      document.querySelectorAll('.v-input, .form-group, fieldset').forEach(wrap => {
        if (wrap.closest('#fc-floating-root')) return;
        const labelEl = wrap.querySelector('label, .v-label, legend');
        const labelTxt = (labelEl ? labelEl.textContent : wrap.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        const vInst = wrap.__vue__;

        // A. Khudro Nrigosthi Kina -> No (না)
        if (/ক্ষুদ্র|নৃ-গোষ্ঠী|নৃগোষ্ঠী|ethnic|tribal/.test(labelTxt)) {
          const wantYes = Number(isEthnic) === 1;
          if (vInst && Array.isArray(vInst.items) && vInst.items.length > 0) {
            const targetItem = vInst.items.find(it => {
              if (typeof it === 'object' && it !== null) {
                const t = `${it.text || ''} ${it.name_bn || ''} ${it.name_en || ''} ${it.label || ''} ${it.title || ''}`.trim().toLowerCase();
                const v = String(it.value ?? it.id ?? '').toLowerCase();
                return wantYes
                  ? (t === 'হ্যাঁ' || t === 'yes' || v === '1' || v === 'true')
                  : (t === 'না' || t === 'no' || v === '0' || v === 'false');
              }
              return wantYes
                ? (String(it).toLowerCase() === 'হ্যাঁ' || String(it) === '1')
                : (String(it).toLowerCase() === 'না' || String(it) === '0');
            });
            if (targetItem !== undefined) {
              const val = (typeof targetItem === 'object' && targetItem !== null) ? (targetItem.value ?? targetItem.id ?? 0) : targetItem;
              vInst.$emit('input', val);
              vInst.$emit('change', val);
            }
          }
          wrap.querySelectorAll('input[type="radio"]').forEach(rad => {
            const rLbl = (rad.closest('.v-radio, label')?.textContent || '').trim().toLowerCase();
            const rVal = String(rad.value || '').toLowerCase();
            const match = wantYes
              ? (rLbl === 'হ্যাঁ' || rLbl === 'yes' || rVal === '1' || rVal === 'true')
              : (rLbl === 'না' || rLbl === 'no' || rVal === '0' || rVal === 'false');
            if (match && !rad.checked) {
              rad.click();
              rad.dispatchEvent(new Event('change', { bubbles: true }));
            }
          });
          wrap.querySelectorAll('select').forEach(sel => {
            const opt = Array.from(sel.options).find(o => {
              const t = o.textContent.trim().toLowerCase();
              const v = String(o.value).toLowerCase();
              return wantYes
                ? (t === 'হ্যাঁ' || t === 'yes' || v === '1' || v === 'true')
                : (t === 'না' || t === 'no' || v === '0' || v === 'false');
            });
            if (opt && sel.value !== opt.value) {
              sel.value = opt.value;
              sel.dispatchEvent(new Event('change', { bubbles: true }));
            }
          });
        }

        // B. Area Type / Elaka -> Polli / Union (পল্লী / ইউনিয়ন)
        if (/এলাকার ধরন|বাসস্থানের ধরন|অবস্থান|এলাকা নির্বাচন|location type|area type/.test(labelTxt) ||
            (vInst && Array.isArray(vInst.items) && vInst.items.some(it => /পৌরসভা|সিটি কর্পোরেশন|পল্লী/.test(JSON.stringify(it))))) {
          const areaPattern = areaTypeId === 2 ? /পৌরসভা|pourashava|municipality/i : (areaTypeId === 3 ? /সিটি|city/i : /পল্লী|ইউনিয়ন|ইউনিয়ন|rural|union/i);
          if (vInst && Array.isArray(vInst.items) && vInst.items.length > 0) {
            const areaItem = vInst.items.find(it => {
              const t = typeof it === 'object' && it !== null
                ? `${it.text || ''} ${it.name_bn || ''} ${it.name_en || ''} ${it.label || ''} ${it.title_bn || ''} ${it.name || ''}`
                : String(it);
              return areaPattern.test(t);
            });
            if (areaItem !== undefined) {
              const val = (typeof areaItem === 'object' && areaItem !== null) ? (areaItem.value ?? areaItem.id ?? areaItem.code) : areaItem;
              vInst.$emit('input', val);
              vInst.$emit('change', val);
            }
          }
          wrap.querySelectorAll('input[type="radio"]').forEach(rad => {
            const rLbl = (rad.closest('.v-radio, label')?.textContent || '').trim().toLowerCase();
            if (areaPattern.test(rLbl) && !rad.checked) {
              rad.click();
              rad.dispatchEvent(new Event('change', { bubbles: true }));
            }
          });
          wrap.querySelectorAll('select').forEach(sel => {
            const opt = Array.from(sel.options).find(o => areaPattern.test(o.textContent));
            if (opt && sel.value !== opt.value) {
              sel.value = opt.value;
              sel.dispatchEvent(new Event('change', { bubbles: true }));
            }
          });
        }

        // C. Children Under 18 (শিশু সংখ্যা) DOM Input
        if (/শিশু সংখ্যা|শিশুর সংখ্যা|১৮ বছরের নিচে|কতজন শিশু|number of children|children count/.test(labelTxt)) {
          const inp = wrap.querySelector('input[type="text"], input[type="number"]');
          if (inp) {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
            if (nativeSetter) nativeSetter.call(inp, String(childrenUnder18));
            else inp.value = String(childrenUnder18);
            inp.dispatchEvent(new Event('input', { bubbles: true }));
            inp.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }

        // D. Total Household Members (পরিবারের সদস্য সংখ্যা / খানার সদস্য সংখ্যা) DOM Input
        if (/সদস্য সংখ্যা|খানার সদস্য|পরিবারের সদস্য|total member|family size|house size/.test(labelTxt) && !/শিশু|child/.test(labelTxt)) {
          const inp = wrap.querySelector('input[type="text"], input[type="number"]');
          if (inp) {
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
            if (nativeSetter) nativeSetter.call(inp, String(totalMembers));
            else inp.value = String(totalMembers);
            inp.dispatchEvent(new Event('input', { bubbles: true }));
            inp.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }
      });
    }

    function parseMemberRow(m) {
      const relId = Number(m.relationship_id || m.relation_id || 0);
      const relName = ID_TO_RELATION_MAP[relId] || m.relation || 'Son';
      const finalRelId = relId || RELATION_ID_MAP[relName] || 160;

      const verType = Number(m.verification_type);
      const idVal = String(m.verification_number || (verType === 2 ? m.brn_id : m.nid) || m.brn_id || m.nid || '').trim();
      const isBRN = verType === 2 || (!verType && idVal.length === 17 && Boolean(m.brn_id));

      const gVal = Number(m.gender_id || m.gender || 0);
      let genderStr = 'Male';
      if (gVal === 2) genderStr = 'Female';
      else if (gVal === 3) genderStr = 'Other';
      else if (!gVal && RELATION_GENDER_MAP[relName] === 2) genderStr = 'Female';

      return {
        relation: relName === 'Head/Self' ? 'Wife' : relName,
        relationship_id: finalRelId,
        gender: genderStr,
        gender_id: gVal || (genderStr === 'Female' ? 2 : 1),
        doc_type: isBRN ? 'BRN' : 'NID',
        nid_or_brn: idVal,
        dob: m.date_of_birth || m.dob || '',
        name_bn: m.name_bn || '',
        name_en: m.name_en || '',
        father_name_bn: m.father_name_bn || '',
        father_name_en: m.father_name_en || '',
        mother_name_bn: m.mother_name_bn || '',
        mother_name_en: m.mother_name_en || '',
        is_disabled: Number(m.is_member_disabled) === 1 ? 1 : 0
      };
    }

    function isRowPopulated(m) {
      if (!m) return false;
      return Boolean(
        (m.verification_number && String(m.verification_number).trim()) ||
        (m.nid && String(m.nid).trim()) ||
        (m.brn_id && String(m.brn_id).trim()) ||
        (m.name_bn && String(m.name_bn).trim()) ||
        (m.name_en && String(m.name_en).trim())
      );
    }

    window.addEventListener('FC_PRO_AUTOFILL', async (event) => {
      const payload = event.detail;
      if (!payload) return;

      const { vmHead, vmMembers, allVms } = getVueNodes();
      if (!vmHead && !vmMembers && (!allVms || !allVms.length)) {
        window.dispatchEvent(new CustomEvent('FC_PRO_AUTOFILL_RESULT', {
          detail: { success: false, message: 'Vue application form not detected on this page.' }
        }));
        return;
      }

      try {
        const setReactive = (vmTarget, targetObj, key, val) => {
          if (!targetObj || val === undefined || val === null) return;
          if (vmTarget && typeof vmTarget.$set === 'function') vmTarget.$set(targetObj, key, val);
          else targetObj[key] = val;
        };

        if (vmHead && 'panel' in vmHead) vmHead.panel = [0, 1, 2, 3, 4, 5, 6, 7];
        if (vmMembers && 'panel' in vmMembers) vmMembers.panel = [0, 1, 2, 3, 4, 5, 6, 7];

        // 0. Restore Full Website Dump & Tab Editor changes
        if (payload.full_form_dump) {
          const dump = payload.full_form_dump;
          if (dump.head_data && vmHead && vmHead.data) {
            Object.entries(dump.head_data).forEach(([k, v]) => {
              if (v !== undefined && typeof v !== 'function') {
                setReactive(vmHead, vmHead.data, k, v);
              }
            });
          }
          if (Array.isArray(dump.family_members_raw) && vmMembers && Array.isArray(vmMembers.familyMembers)) {
            while (vmMembers.familyMembers.length < dump.family_members_raw.length) {
              if (typeof vmMembers.addFamilyMember === 'function') vmMembers.addFamilyMember();
              else vmMembers.familyMembers.push({});
            }
            await new Promise((r) => setTimeout(r, 150));
            dump.family_members_raw.forEach((rawRow, idx) => {
              const targetRow = vmMembers.familyMembers[idx];
              if (!targetRow || !rawRow) return;
              Object.entries(rawRow).forEach(([k, v]) => {
                if (v !== undefined && typeof v !== 'function') {
                  setReactive(vmMembers, targetRow, k, v);
                }
              });
            });
          }
          if (Array.isArray(dump.dom_tabs)) {
            dump.dom_tabs.forEach((tab) => {
              (tab.fields || []).forEach((f) => {
                if (!f.dom_key) return;
                const el = document.querySelector(`[data-fc-dom-key="${f.dom_key}"]`) || (f.id ? document.getElementById(f.id) : null);
                if (!el) return;
                if (el.tagName === 'SELECT') {
                  el.value = f.value;
                  el.dispatchEvent(new Event('change', { bubbles: true }));
                } else if (el.type === 'checkbox' || el.type === 'radio') {
                  el.checked = Boolean(f.value);
                  el.dispatchEvent(new Event('change', { bubbles: true }));
                } else {
                  el.value = f.value;
                  el.dispatchEvent(new Event('input', { bubbles: true }));
                  el.dispatchEvent(new Event('change', { bubbles: true }));
                }
              });
            });
          }
        }

        // 1. Populate Primary Applicant (Head) in main form & Verification
        if (payload.head) {
          const h = payload.head;
          const cleanHeadId = String(h.nid || '').replace(/\s+/g, '');
          const headIsNID = determineIsNID(h.doc_type, cleanHeadId);
          const headGenderId = resolveGenderId({ ...h, relation: 'Head/Self' });
          const headDobParts = parseDobParts(h.dob);
          const headModelDob = headDobParts ? headDobParts.iso : String(h.dob || '').replace(/\[.*?\]/g, '').replace(/-/g, '/');

          const isVerificationPage = Boolean(
            document.querySelector('input[placeholder*="ক্যাপচা"], input[placeholder*="উত্তর"], input[id*="captcha"], .captcha-container') ||
            Array.from(document.querySelectorAll('label, span, p')).some(el => el.textContent.includes('ক্যাপচা সম্পূর্ণ করুন'))
          );

          if (vmHead && vmHead.data) {
            setReactive(vmHead, vmHead.data, 'verification_type', headIsNID ? 1 : 2);
            setReactive(vmHead, vmHead.data, 'verification_number', cleanHeadId);
            setReactive(vmHead, vmHead.data, 'nid', headIsNID ? cleanHeadId : '');
            setReactive(vmHead, vmHead.data, 'brn_id', !headIsNID ? cleanHeadId : '');
            setReactive(vmHead, vmHead.data, 'date_of_birth', headModelDob);
            setReactive(vmHead, vmHead.data, 'dob', headModelDob);

            setReactive(vmHead, vmHead.data, 'name_bn', h.name_bn);
            setReactive(vmHead, vmHead.data, 'name_en', h.name_en);
            setReactive(vmHead, vmHead.data, 'father_name_bn', h.father_name_bn);
            setReactive(vmHead, vmHead.data, 'father_name_en', h.father_name_en);
            setReactive(vmHead, vmHead.data, 'mother_name_bn', h.mother_name_bn);
            setReactive(vmHead, vmHead.data, 'mother_name_en', h.mother_name_en);

            // GENDER: Excluded strictly on the verification/captcha page, filled normally on main form
            if (!isVerificationPage) {
              setReactive(vmHead, vmHead.data, 'gender', headGenderId);
              setReactive(vmHead, vmHead.data, 'gender_id', headGenderId);
              setReactive(vmHead, vmHead.data, 'sex', headGenderId);
              setReactive(vmHead, vmHead.data, 'applicant_gender', headGenderId);
            }
          }

          await selectDateViaVuetifyCalendar(h.dob, 0);
        }

        // 2. Combine Head as Member 1, then the rest of the family
        const fullFamilyList = [];
        if (payload.head) {
          fullFamilyList.push({
            ...payload.head,
            relation: 'Head/Self',
            gender: payload.head.gender || 'Female',
            gender_id: resolveGenderId({ ...payload.head, relation: 'Head/Self' }),
            doc_type: payload.head.doc_type || 'NID',
            nid_or_brn: payload.head.nid,
            relationship_id: 185
          });
        }
        if (Array.isArray(payload.family_members)) {
          fullFamilyList.push(...payload.family_members);
        }

        const calcChildrenCount = fullFamilyList.filter(m => {
          const age = calculateAgeYears(m.dob);
          return age !== null && age >= 0 && age < 18;
        }).length;

        const defs = payload.form_defaults || {};
        const totalMembersCount = defs.total_members !== undefined ? Number(defs.total_members) : fullFamilyList.length;
        const childrenUnder18Count = defs.children_under_18 !== undefined ? Number(defs.children_under_18) : calcChildrenCount;
        const isEthnicVal = defs.is_ethnic !== undefined ? Number(defs.is_ethnic) : 0;
        const areaTypeVal = defs.area_type_id !== undefined ? Number(defs.area_type_id) : 1;

        // 3. Inject into the Member Array
        if (fullFamilyList.length > 0 && vmMembers && Array.isArray(vmMembers.familyMembers)) {
          while (vmMembers.familyMembers.length < fullFamilyList.length) {
            if (typeof vmMembers.addFamilyMember === 'function') vmMembers.addFamilyMember();
            else vmMembers.familyMembers.push({});
          }

          await new Promise((r) => setTimeout(r, 150));

          for (let idx = 0; idx < fullFamilyList.length; idx++) {
            const m = fullFamilyList[idx];
            const row = vmMembers.familyMembers[idx];
            if (!row) continue;

            const cleanId = String(m.nid_or_brn || '').replace(/\s+/g, '');
            const isNID = determineIsNID(m.doc_type, cleanId);
            const genderId = resolveGenderId(m);
            const relId = Number(m.relationship_id || RELATION_ID_MAP[m.relation] || 160);
            const memAge = calculateAgeYears(m.dob);

            setReactive(vmMembers, row, 'verification_type', isNID ? 1 : 2);
            
            if (isNID) {
              setReactive(vmMembers, row, 'nid', cleanId);
              setReactive(vmMembers, row, 'brn_id', '');
              setReactive(vmMembers, row, 'verification_number', cleanId);
            } else {
              setReactive(vmMembers, row, 'brn_id', cleanId);
              setReactive(vmMembers, row, 'nid', '');
              setReactive(vmMembers, row, 'verification_number', cleanId);
            }

            const memDobParts = parseDobParts(m.dob);
            const memModelDob = memDobParts ? memDobParts.iso : String(m.dob || '').replace(/\[.*?\]/g, '').replace(/-/g, '/');
            setReactive(vmMembers, row, 'dob', memModelDob);
            setReactive(vmMembers, row, 'date_of_birth', memModelDob);
            if (memAge !== null && 'age' in row) {
              setReactive(vmMembers, row, 'age', memAge);
            }

            setReactive(vmMembers, row, 'name_bn', m.name_bn);
            setReactive(vmMembers, row, 'name_en', m.name_en);
            setReactive(vmMembers, row, 'father_name_bn', m.father_name_bn);
            setReactive(vmMembers, row, 'mother_name_bn', m.mother_name_bn);

            setReactive(vmMembers, row, 'relationship_id', relId);
            setReactive(vmMembers, row, 'relation_id', relId);
            if (m.relation) setReactive(vmMembers, row, 'relation', m.relation);

            setReactive(vmMembers, row, 'gender', genderId);
            setReactive(vmMembers, row, 'gender_id', genderId);

            setReactive(vmMembers, row, 'is_member_disabled', Number(m.is_disabled) === 1 ? 1 : 0);
            setReactive(vmMembers, row, 'is_gov_job_holder', 0);

            if (m.relation === 'Husband' && !row.estimate_annual_income) {
              setReactive(vmMembers, row, 'estimate_annual_income', 60000);
            }
          }
        }

        // 4. Apply Smart Defaults: Total Members, Children (<18), Khudro Nrigosthi = No, Area Type = Polli/Union
        applySmartFormDefaults(vmHead, vmMembers, totalMembersCount, childrenUnder18Count, isEthnicVal, areaTypeVal);

        if (vmHead && typeof vmHead.$forceUpdate === 'function') vmHead.$forceUpdate();
        if (vmMembers && typeof vmMembers.$forceUpdate === 'function') vmMembers.$forceUpdate();

        window.dispatchEvent(new CustomEvent('FC_PRO_AUTOFILL_RESULT', {
          detail: {
            success: true,
            message: `Auto-filled ${totalMembersCount} member(s) (${childrenUnder18Count} children <18), Polli/Union & Khudro Nrigosthi: No!`
          }
        }));
      } catch (err) {
        window.dispatchEvent(new CustomEvent('FC_PRO_AUTOFILL_RESULT', {
          detail: { success: false, message: `Autofill error: ${err.message}` }
        }));
      }
    });

    window.addEventListener('FC_PRO_PULL_REQUEST', () => {
      const { vmHead, vmMembers, allVms } = getVueNodes();
      if (!vmHead && !vmMembers && (!allVms || !allVms.length)) {
        window.dispatchEvent(new CustomEvent('FC_PRO_PULL_RESULT', {
          detail: { success: false, message: 'No active Vue form instance found on this page.' }
        }));
        return;
      }

      try {
        const d = (vmHead && vmHead.data) ? vmHead.data : {};
        const rawMembers = (vmMembers && Array.isArray(vmMembers.familyMembers)) ? vmMembers.familyMembers : [];

        const row0 = rawMembers[0] || {};
        const dId = String(d.verification_number || d.nid || '').trim();
        const r0Id = String(row0.verification_number || row0.nid || row0.brn_id || '').trim();
        const row0IsHead = Number(row0.relationship_id) === 185 || (dId && r0Id && dId === r0Id) || (!dId && rawMembers.length > 0 && !row0.relationship_id);

        const hSource = row0IsHead ? { ...row0, ...d } : d;
        const headVerType = Number(hSource.verification_type || row0.verification_type || 1);
        const headGenVal = Number(hSource.gender_id || hSource.gender || row0.gender_id || row0.gender || 2);

        const head = {
          doc_type: headVerType === 2 ? 'BRN' : 'NID',
          gender: headGenVal === 1 ? 'Male' : 'Female',
          gender_id: headGenVal === 1 ? 1 : 2,
          nid: String(d.verification_number || d.nid || (row0IsHead ? r0Id : '') || '').trim(),
          dob: d.date_of_birth || d.dob || (row0IsHead ? (row0.date_of_birth || row0.dob) : '') || '',
          name_bn: d.name_bn || (row0IsHead ? row0.name_bn : '') || '',
          name_en: d.name_en || (row0IsHead ? row0.name_en : '') || '',
          father_name_bn: d.father_name_bn || (row0IsHead ? row0.father_name_bn : '') || '',
          father_name_en: d.father_name_en || (row0IsHead ? row0.father_name_en : '') || '',
          mother_name_bn: d.mother_name_bn || (row0IsHead ? row0.mother_name_bn : '') || '',
          mother_name_en: d.mother_name_en || (row0IsHead ? row0.mother_name_en : '') || ''
        };

        const memberSlice = row0IsHead ? rawMembers.slice(1) : rawMembers;
        const family_members = memberSlice.filter(isRowPopulated).map(parseMemberRow);

        const safeClone = (obj) => {
          try { return JSON.parse(JSON.stringify(obj || {})); } catch (e) { return {}; }
        };

        const dom_tabs = [];
        const vueOptionCatalog = {};

        if (vmHead && vmHead.$data) {
          Object.entries(vmHead.$data).forEach(([k, val]) => {
            if (Array.isArray(val) && val.length > 0 && val.length <= 200 && typeof val[0] === 'object' && val[0] !== null) {
              const sample = val[0];
              const idKey = ('id' in sample) ? 'id' : (('value' in sample) ? 'value' : (('code' in sample) ? 'code' : null));
              const nameKey = ('name_bn' in sample) ? 'name_bn' : (('title_bn' in sample) ? 'title_bn' : (('name' in sample) ? 'name' : (('label' in sample) ? 'label' : ('name_en' in sample ? 'name_en' : null))));
              if (idKey && nameKey) {
                vueOptionCatalog[k] = val.map(item => ({
                  value: item[idKey],
                  label: item.name_bn && item.name_en ? `${item.name_bn} (${item.name_en})` : String(item[nameKey])
                }));
              }
            }
          });
        }

        const containers = document.querySelectorAll('.v-expansion-panel, .card, .tab-pane, fieldset, form');
        const roots = containers.length ? Array.from(containers) : [document.body];
        const seenElements = new Set();
        let domKeyCounter = 1;

        roots.forEach((sec, secIdx) => {
          const inputs = Array.from(sec.querySelectorAll('input:not([type="hidden"]):not([type="file"]), select, textarea'))
            .filter(el => !el.closest('#fc-floating-root') && !seenElements.has(el));
          if (!inputs.length) return;

          const headerEl = sec.querySelector('.v-expansion-panel-header, .card-header, h1, h2, h3, h4, h5, legend');
          const tabTitle = headerEl ? headerEl.textContent.replace(/\s+/g, ' ').trim().slice(0, 65) : `Website Section #${secIdx + 1}`;
          const fields = [];

          inputs.forEach((el) => {
            seenElements.add(el);
            const domKey = el.getAttribute('data-fc-dom-key') || `fc_dom_${domKeyCounter++}`;
            el.setAttribute('data-fc-dom-key', domKey);

            let label = '';
            if (el.id) {
              const lblEl = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
              if (lblEl) label = lblEl.textContent;
            }
            if (!label) {
              const wrap = el.closest('.v-input, .form-group, .col-md-6, .col-md-4, .col-12, div');
              const lblEl = wrap ? wrap.querySelector('label, .v-label, .field-label') : null;
              if (lblEl) label = lblEl.textContent;
            }
            label = (label || el.name || el.placeholder || el.id || `Field ${domKeyCounter}`).replace(/\s+/g, ' ').trim();

            if (el.tagName === 'SELECT') {
              const options = Array.from(el.options).map(o => ({ value: o.value, label: o.textContent.trim() }));
              const selectedText = el.options[el.selectedIndex] ? el.options[el.selectedIndex].textContent.trim() : '';
              fields.push({ dom_key: domKey, id: el.id || '', name: el.name || '', label, type: 'select', value: el.value, display_value: selectedText, options });
            } else if (el.type === 'checkbox' || el.type === 'radio') {
              fields.push({
                dom_key: domKey, id: el.id || '', name: el.name || '', label, type: 'boolean', value: el.checked,
                display_value: el.checked ? 'Yes (হ্যাঁ)' : 'No (না)',
                options: [{ value: 'true', label: 'Yes (হ্যাঁ)' }, { value: 'false', label: 'No (না)' }]
              });
            } else {
              fields.push({ dom_key: domKey, id: el.id || '', name: el.name || '', label, type: 'text', value: el.value || '', display_value: el.value || '' });
            }
          });

          if (fields.length) dom_tabs.push({ title: tabTitle, fields });
        });

        const full_form_dump = {
          pulled_at: new Date().toISOString(),
          page_url: location.href,
          head_data: safeClone(d),
          family_members_raw: safeClone(rawMembers),
          vue_options: vueOptionCatalog,
          dom_tabs
        };

        const hasAnyHeadData = Object.values(full_form_dump.head_data).some(v => v !== null && v !== '' && v !== undefined && typeof v !== 'object');
        if (!hasAnyHeadData && !head.nid && !head.name_bn && !head.name_en && family_members.length === 0 && dom_tabs.length === 0) {
          window.dispatchEvent(new CustomEvent('FC_PRO_PULL_RESULT', {
            detail: { success: false, message: 'Web form is currently empty — nothing to pull.' }
          }));
          return;
        }

        window.dispatchEvent(new CustomEvent('FC_PRO_PULL_RESULT', {
          detail: { success: true, payload: { head, family_members, full_form_dump } }
        }));
      } catch (err) {
        window.dispatchEvent(new CustomEvent('FC_PRO_PULL_RESULT', {
          detail: { success: false, message: err.message }
        }));
      }
    });

  })();

  const isMobileDevice = window.screen.width <= 768;
  const viewClass = isMobileDevice ? 'fc-mobile-view' : 'fc-desktop-view';

  const style = document.createElement('style');
  style.setAttribute('data-fc', 'true');
  style.textContent = `
    #fc-floating-root {
      position: fixed; inset: 0; z-index: 2147483000; pointer-events: none; font-family: Inter, system-ui, sans-serif;
    }
    #fc-trigger-btn {
      position: fixed; bottom: 20px; right: 20px; pointer-events: auto;
      display: flex; align-items: center; gap: 8px; padding: 10px 16px;
      background: #0f172a; color: #ffffff; border: 1px solid #334155;
      border-radius: 999px; font-size: 13px; font-weight: 650; cursor: pointer;
      box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3); transition: transform 0.15s ease;
    }
    #fc-trigger-btn:hover { transform: scale(1.05); }
    #fc-trigger-btn.active { transform: scale(0.9); }

    #fc-drawer-iframe {
      position: fixed; background: #ffffff; border: none;
      pointer-events: auto;
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .fc-mobile-view #fc-drawer-iframe {
      bottom: 0; left: 0; right: 0; width: 100%; height: 90vh; max-height: 850px;
      border-top-left-radius: 20px; border-top-right-radius: 20px;
      box-shadow: -10px 0 40px rgba(0,0,0,0.3);
      transform: translateY(105%);
    }
    .fc-mobile-view #fc-drawer-iframe.open { transform: translateY(0); }

    .fc-desktop-view #fc-drawer-iframe {
      top: 0; bottom: 0; right: 0; left: auto;
      width: 420px; height: 100%; max-height: none;
      border-radius: 0; border-left: 1px solid #cbd5e1;
      box-shadow: -10px 0 40px rgba(0,0,0,0.15);
      transform: translateX(105%);
    }
    .fc-desktop-view #fc-drawer-iframe.open { transform: translateX(0); }
  `;
  document.head.appendChild(style);

  const root = document.createElement('div');
  root.id = 'fc-floating-root';
  root.className = viewClass;

  const trigger = document.createElement('button');
  trigger.id = 'fc-trigger-btn';
  trigger.type = 'button';
  trigger.innerHTML = '<span style="width:10px;height:10px;border-radius:50%;background:#22c55e;box-shadow:0 0 8px #22c55e;"></span><span>Family Card AI</span>';

  const iframe = document.createElement('iframe');
  iframe.id = 'fc-drawer-iframe';
  iframe.title = 'Family Card Pro';
  iframe.src = panelUrl;
  iframe.setAttribute('allow', 'camera; clipboard-read; clipboard-write');

  root.append(trigger, iframe);
  (document.body || document.documentElement).appendChild(root);

  const STORAGE_KEY = 'fc_pro_api_key';
  const STORAGE_MODEL = 'fc_pro_model';
  const SESSION_DRAFT_KEY = 'fc_pro_active_session';
  let isOpen = false;

  function sendToPanel(message) {
    if (iframe.contentWindow) iframe.contentWindow.postMessage(message, panelOrigin);
  }
  function pushSavedCredentials() {
    try {
      sendToPanel({
        action: 'FC_API_KEY_DATA',
        apiKey: localStorage.getItem(STORAGE_KEY) || '',
        model: localStorage.getItem(STORAGE_MODEL) || 'gemini-2.5-flash'
      });
      const savedSession = sessionStorage.getItem(SESSION_DRAFT_KEY);
      if (savedSession) {
        sendToPanel({
          action: 'FC_RESTORE_SESSION',
          sessionData: JSON.parse(savedSession)
        });
      }
    } catch (e) {}
  }
  function closeSheet() {
    isOpen = false;
    iframe.classList.remove('open');
    trigger.classList.remove('active');
  }
  function toggleSheet() {
    isOpen = !isOpen;
    if (isOpen) {
      iframe.classList.add('open');
      trigger.classList.add('active');
      sendToPanel({ action: 'FC_STATUS_REPLY', online: true });
      pushSavedCredentials();
    } else {
      closeSheet();
    }
  }

  iframe.addEventListener('load', () => {
    sendToPanel({ action: 'FC_STATUS_REPLY', online: true });
    pushSavedCredentials();
  });

  root.__fcToggle = toggleSheet;
  trigger.addEventListener('click', toggleSheet);

  setTimeout(() => { if (!isOpen) toggleSheet(); }, 100);

  window.addEventListener('message', (event) => {
    if (event.source !== iframe.contentWindow || event.origin !== panelOrigin || !event.data) return;
    const data = event.data;
    if (data.action === 'FC_CLOSE_SHEET') closeSheet();
    if (data.action === 'FC_CHECK_STATUS') {
      sendToPanel({ action: 'FC_STATUS_REPLY', online: true });
      pushSavedCredentials();
    }
    if (data.action === 'FC_GET_API_KEY') {
      pushSavedCredentials();
    }
    if (data.action === 'FC_SAVE_API_KEY') {
      try {
        if (data.apiKey !== undefined) localStorage.setItem(STORAGE_KEY, data.apiKey);
        if (data.model !== undefined) localStorage.setItem(STORAGE_MODEL, data.model);
      } catch (e) {}
    }
    if (data.action === 'FC_SAVE_SESSION') {
      try {
        if (data.sessionData) {
          sessionStorage.setItem(SESSION_DRAFT_KEY, JSON.stringify(data.sessionData));
        } else {
          sessionStorage.removeItem(SESSION_DRAFT_KEY);
        }
      } catch (e) {}
    }
    if (data.action === 'FILL_VUE_FORM') {
      window.dispatchEvent(new CustomEvent('FC_PRO_AUTOFILL', { detail: data.payload }));
    }
    if (data.action === 'FC_PULL_DRAFT') {
      window.dispatchEvent(new CustomEvent('FC_PRO_PULL_REQUEST'));
    }
    if (data.action === 'FC_DOWNLOAD_JSON') {
      try {
        const blob = new Blob([data.jsonString], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = data.filename || 'family-card-backup.json';
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
      } catch (e) {}
    }
    if (data.action === 'FC_COPY_TEXT') {
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(data.text);
        } else throw new Error('fallback');
      } catch (e) {
        const ta = document.createElement('textarea');
        ta.value = data.text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
      }
    }
  });

  window.addEventListener('FC_PRO_AUTOFILL_RESULT', (event) => {
    sendToPanel({ action: 'FC_AUTOFILL_RESPONSE', detail: event.detail });
  });

  window.addEventListener('FC_PRO_PULL_RESULT', (event) => {
    sendToPanel({ action: 'FC_PULL_RESPONSE', detail: event.detail });
  });

})();
